// ============================================
//  Loud Mic — Popup Controller
//  Gain knob (0–100) controls REAL mic gain.
//  Communicates with content script → MAIN world
//  via background service worker.
// ============================================

document.addEventListener('DOMContentLoaded', function () {

  var GAIN_MAX   = 100;
  var isActive   = false;
  var currentGain = 1;
  var vuAnimId   = null;

  /* ── DOM refs ── */
  var knobEl      = document.getElementById('knobGain');
  var valEl       = document.getElementById('valGain');
  var vuFill      = document.getElementById('vuFill');
  var btn         = document.getElementById('activateBtn');
  var statusDot   = document.getElementById('statusDot');
  var statusTxt   = document.getElementById('statusText');
  var ledStandby  = document.getElementById('ledStandby');
  var ledActive   = document.getElementById('ledActive');

  /* ── GAIN KNOB DRAG ── */
  var knobMin = +knobEl.dataset.min;   // 0
  var knobMax = +knobEl.dataset.max;   // 100
  var knobVal = +knobEl.dataset.value; // 1 (default)
  var knobBody = knobEl.querySelector('.knob-body');

  function renderKnob() {
    var pct   = (knobVal - knobMin) / (knobMax - knobMin);
    var angle = -135 + pct * 270;
    knobBody.style.transform = 'rotate(' + angle + 'deg)';

    var rounded = Math.round(knobVal * 10) / 10; // one decimal
    valEl.textContent = rounded + 'x';

    /* Color feedback */
    valEl.classList.remove('hot', 'warm');
    if (rounded >= 70) valEl.classList.add('hot');
    else if (rounded >= 30) valEl.classList.add('warm');

    currentGain = rounded;
    saveState();

    /* Live-update gain if active */
    if (isActive) sendGain(currentGain);
  }

  renderKnob();

  function startDrag(e) {
    e.preventDefault();
    var startY   = e.clientY || e.touches[0].clientY;
    var startVal = knobVal;

    function onMove(ev) {
      var y     = ev.clientY || ev.touches[0].clientY;
      var delta = (startY - y) * 0.25;
      knobVal   = Math.max(knobMin, Math.min(knobMax, startVal + delta));
      renderKnob();
    }
    function onEnd() {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onEnd);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onEnd);
    }

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
  }

  knobEl.addEventListener('mousedown', startDrag);
  knobEl.addEventListener('touchstart', startDrag, { passive: false });

  /* ── SMALL KNOBS (cosmetic) ── */
  document.querySelectorAll('.knob-row .knob').forEach(function (k) {
    var mn = +k.dataset.min, mx = +k.dataset.max, v = +k.dataset.value;
    var body = k.querySelector('.knob-body');
    var label = k.closest('.knob-group').querySelector('.knob-value');

    function draw() {
      var pct = (v - mn) / (mx - mn);
      body.style.transform = 'rotate(' + (-135 + pct * 270) + 'deg)';
      var r = Math.round(v);
      label.textContent = (r > 0 ? '+' : '') + r + ' dB';
    }
    draw();

    k.addEventListener('mousedown', function (e) {
      e.preventDefault();
      var sy = e.clientY, sv = v;
      function mv(ev) { v = Math.max(mn, Math.min(mx, sv + (sy - ev.clientY) * 0.12)); draw(); }
      function up() { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); }
      document.addEventListener('mousemove', mv);
      document.addEventListener('mouseup', up);
    });
  });

  /* ── SLIDERS ── */
  var volSlider = document.getElementById('volumeSlider');
  var volVal    = document.getElementById('volumeVal');
  volSlider.addEventListener('input', function () { volVal.textContent = volSlider.value + ' %'; });

  var thSlider = document.getElementById('thresholdSlider');
  var thVal    = document.getElementById('thresholdVal');
  thSlider.addEventListener('input', function () { thVal.textContent = thSlider.value + ' dB'; });

  /* ── TOGGLES ── */
  document.querySelectorAll('.toggle').forEach(function (t) {
    t.addEventListener('click', function () { t.classList.toggle('active'); });
  });

  /* ── VU METER ── */
  function animateVU() {
    var base  = currentGain > 1 ? Math.min(80, 20 + currentGain * 0.6) : 0;
    var noise = (Math.random() - 0.5) * 18;
    var level = Math.max(0, Math.min(100, base + noise));
    vuFill.style.width = level + '%';
    vuAnimId = requestAnimationFrame(animateVU);
  }

  /* ── ACTIVATE / DEACTIVATE ── */
  btn.addEventListener('click', function () {
    isActive = !isActive;

    if (isActive) {
      btn.innerHTML = '<span class="btn-icon">🔇</span> DEACTIVATE';
      btn.classList.add('on');
      statusDot.classList.add('active');
      statusTxt.classList.add('active');
      statusTxt.textContent = 'ACTIVE  ' + currentGain + 'x';
      ledStandby.classList.add('off');
      ledActive.classList.add('on');
      sendGain(currentGain);
      animateVU();
    } else {
      btn.innerHTML = '<span class="btn-icon">🎤</span> ACTIVATE LOUD MIC';
      btn.classList.remove('on');
      statusDot.classList.remove('active');
      statusTxt.classList.remove('active');
      statusTxt.textContent = 'STANDBY';
      ledStandby.classList.remove('off');
      ledActive.classList.remove('on');
      sendDeactivate();
      if (vuAnimId) cancelAnimationFrame(vuAnimId);
      vuFill.style.width = '0%';
    }
    saveState();
  });

  /* ── MESSAGING ── */
  function sendGain(g) {
    try { chrome.runtime.sendMessage({ type: 'POPUP_SET_GAIN', gain: g }); } catch (_) {}
  }
  function sendDeactivate() {
    try { chrome.runtime.sendMessage({ type: 'POPUP_DEACTIVATE' }); } catch (_) {}
  }

  /* ── PERSISTENCE ── */
  function saveState() {
    try {
      chrome.storage.local.set({ loudmic_gain: currentGain, loudmic_active: isActive });
    } catch (_) {}
  }

  function loadState() {
    try {
      chrome.storage.local.get(['loudmic_gain', 'loudmic_active'], function (d) {
        if (d.loudmic_gain !== undefined) {
          knobVal = Math.max(0, Math.min(100, d.loudmic_gain));
          renderKnob();
        }
        if (d.loudmic_active) {
          /* Auto-restore active state */
          btn.click();
        }
      });
    } catch (_) {}
  }

  loadState();
});